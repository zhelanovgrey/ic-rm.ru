tinyMCE.addI18n('fi.modxlink',{
    link_desc:"Insert/edit link"
});