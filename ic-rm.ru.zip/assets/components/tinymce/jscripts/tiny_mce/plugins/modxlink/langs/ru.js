tinyMCE.addI18n('ru.modxlink',{
    link_desc:"Добавить/Изменить ссылку"
});
