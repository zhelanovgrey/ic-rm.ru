tinyMCE.addI18n('ms.modxlink',{
    link_desc:"Insert/edit link"
});