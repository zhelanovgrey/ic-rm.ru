tinyMCE.addI18n('ja.modxlink',{
    link_desc:"Insert/edit link"
});