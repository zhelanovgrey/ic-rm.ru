$('#calculate_input').change(function() {
    var calc = $('#calculate_input').val();
    if(calc.length != 0) {
        $('#calculate_button').removeAttr('disabled');
    } else {
        $('#calculate_button').attr('disabled', 'disabled');
    }
});

$(document).ready(function() {
     AjaxForm.Message.success = function() {};
 });
 $(document).on('af_complete', function(event, response) {
     var form = response.form;
     if (response.success) {
       form.parents('.modal').modal('hide');
       $('#successModal .modal-body').html(response.message);
       $('#successModal').modal('show');
    }
});

$(document).ready(function(){
  $(":input").inputmask();
  $(".phones").inputmask("+7(999) 999-99-99",{ "clearIncomplete": true });
  $("#calculate_input").inputmask("99.99.9999",{ "clearIncomplete": true });
  $('.email').inputmask({
    mask: "*{1,20}[.*{1,20}]@*{1,20}.[*{2,4}]",
    greedy: false,
    clearIncomplete: true,
    onBeforePaste: function (pastedValue, opts) {
      pastedValue = pastedValue.toLowerCase();
      return pastedValue.replace("mailto:", "");
    },
    definitions: {
      '*': {
        validator: "[0-9A-Za-z-а-я-_]",
        casing: "lower"
      }
    }
  }
  );
});

//  MMENU
// ======================================================
   jQuery(document).ready(function( $ ) {
      $("#menu").mmenu({
         "counters": true,
         navbar: {
            title: "МЕНЮ"
          },
         "navbars": [
            {
               "position": "top"
            },
            {
               "position": "top",
               "content": [
                  "<button id = 'close-mmenu'>Закрыть меню</button>"
               ]
            }
         ],
         "extensions": [
             "position-right",
             "pagedim-black",
             "multiline"
          ]
      });
      var API = $("#menu").data( "mmenu" );
      $("#close-mmenu").click(function() {
         API.close();
      });
      $("#open-mmenu, #mmenu").click(function() {
         API.open();
      });
   });

// ==========================================================================
$(window).on("load", function() {
  var slider = $(".slider");
  slider.slick({
    autoplay:false,
    centerMode: true,
    centerPadding: '10px',
    slidesToShow: 5,
    arrows: false,
    responsive: [
    {
      breakpoint: 992,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 3
      }
    },
    {
      breakpoint: 600,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 1
      }
    }
    ]
  });
  var dot = $(".dots-item");
  slider.on("beforeChange", function(event, slick, currentSlide, nextSlide) {
    dot.removeClass("dots-item__active").eq(nextSlide).addClass("dots-item__active")
  });
  dot.on("click", function() {
    var i = dot.index(this);
    slider.slick("slickGoTo", i)
  });
});

$(".slider-left").on("click", function() {
    $('.slider').slick("slickPrev")
});
$(".slider-right").on("click", function() {
    $('.slider').slick("slickNext")
});


/*  кнопка наверх
=======================================================*/
$(function(){
  $('.up').on('click', function(e){
    e.preventDefault();
    var plansOffset = $('.article').offset().top;
    $('html, body').animate({
      scrollTop: plansOffset
    }, 1000);
  });
});
$(window).scroll(function(){
      if ($(this).scrollTop() > 300) {
          $('.up').css('right', '50px');
      } else {
          $('.up').css('right', '-150px');
      }
});




// открываем и закрываем модальное окно
// =====================================================================================
// $(".order-test__but,.develop__but,.phone-order__but").on("click", function(e){
// 	e.preventDefault();
// 	$(".modal, .overlay-modal").fadeIn(); 
// });
// $(".overlay-modal,.fa-times").on("click", function(e){
// 	e.preventDefault();
// 	$(".modal, .overlay-modal").fadeOut(); 
// });


/*  https://fancyapps.com/fancybox/3/docs/
==================================================================*/         
 $('[data-fancybox="images"]').fancybox({
   buttons : [
     'share',
     'thumbs',
     'close'
   ]
 });
 
 

function theRotator() {
	// Устанавливаем прозрачность всех картинок в 0
	$('div#rotator ul li').css({opacity: 0.0});
 
	// Берем первую картинку и показываем ее (по пути включаем полную видимость)
	$('div#rotator ul li:first').css({opacity: 1.0});
 
	// Вызываем функцию rotate для запуска слайдшоу, 5000 = смена картинок происходит раз в 5 секунд
	setInterval('rotate()',4000);
}
 
function rotate() {	
	// Берем первую картинку
	var current = ($('div#rotator ul li.show')?  $('div#rotator ul li.show') : $('div#rotator ul li:first'));
 
	// Берем следующую картинку, когда дойдем до последней начинаем с начала
	var next = ((current.next().length) ? ((current.next().hasClass('show')) ? $('div#rotator ul li:first') :current.next()) : $('div#rotator ul li:first'));	
 
	// Расскомментируйте, чтобы показвать картинки в случайном порядке
	// var sibs = current.siblings();
	// var rndNum = Math.floor(Math.random() * sibs.length );
	// var next = $( sibs[ rndNum ] );
 
	// Подключаем эффект растворения/затухания для показа картинок, css-класс show имеет больший z-index
	next.css({opacity: 0.0})
	.addClass('show')
	.animate({opacity: 1.0}, 1000);
 
	// Прячем текущую картинку
	current.animate({opacity: 0.0}, 1000)
	.removeClass('show');
};
 
$(document).ready(function() {		
	// Запускаем слайдшоу
	theRotator();
});

// закреплям навигацию при прокрутке
// ===================================================
$(window).on("scroll", function () {
    var scrolled = $(this).scrollTop();
    if( scrolled > 150 ) {
      $('.fixed-navigation').css('top', '0');  
    }   
    if( scrolled <= 150 ) {     
       $('.fixed-navigation').css('top', '-200px');
    }
});






